/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: khazyer
 *
 * Created on 3 de Abril de 2017, 19:05
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/*
 * 
 */
//ncomp = Número de comparações
//nTrocas = Trocas de posições no vetor
int nComp = 0, nTrocas = 0;

int PrintVector(int vet[], int tam) {
    for (int i = 0; i < tam; i++) {//print orderede vector
        printf("%d\n", vet[i]);
    }
    return 0;
}

int OpenFileRead(char nome[], int **vet) {
    //abertura do arquivo
    int tam = 0;
    FILE *f;
    f = fopen(nome, "r");
    if (f == NULL) {
        printf("falha ao abrir o arquivo");
        return (1);
    }
    while (feof(f) == 0) {
        if (tam > 0) {
            *vet = (int*) realloc(*vet, (tam + 1) * sizeof (int));
            if (*vet == NULL) {
                printf("erro ao realocoar memoria\n");
                exit(1);
            }
            fscanf(f, "%d\n", (*vet + tam));
        } else {
            fscanf(f, "%d", (*vet + tam));
        }
        tam++;
    }//fill Vector from archive
    fclose(f);
    return tam;
}

int OpenFileWrite(char nome[], int vet[], int tam) {
    //abertura do arquivo
    FILE *f;
    f = fopen(nome, "w");
    if (f == NULL) {
        printf("falha ao abrir o arquivo");
        return (1);
    }
    for (int i = 0; i < tam; i++)//print orderede vector
        fprintf(f, "%d\n", vet[i]);
    fclose(f);
    return 0;
}

int MergeSort(int vet[], int inicio, int fim) {
    int meio = (inicio + fim) / 2;
    if (inicio < fim) {
        MergeSort(vet, inicio, meio);
        MergeSort(vet, meio + 1, fim);
        Merge(vet, inicio, meio, fim);
    }
    return 0;
}

void Merge(int vet[], int inicio, int meio, int fim) {
    //v1:posição vetor 1    qtdv1=quantidade de elementos v1
    //v2:posição vetor 2    qtdv2=quantidade de elementos v2
    int v1 = inicio, qtdv1 = meio - inicio + 1, qtdv2 = fim - meio, v2 = meio + 1, vAux[(fim - inicio) + 1], i = 0;
    while (qtdv1 > 0 && qtdv2 > 0) {
        if (vet[v1] <= vet[v2]) {
            vAux[i] = vet[v1];
            nTrocas++;
            i++;
            v1++;
            qtdv1--;
        } else {
            vAux[i] = vet[v2];
            nTrocas++;
            i++;
            v2++;
            qtdv2--;
        }
    }
    if (qtdv1 > 0) {
        while (qtdv1 > 0) {
            vAux[i] = vet[v1];
            nTrocas++;
            i++;
            v1++;
            qtdv1--;
        }
    } else if (qtdv2 > 0) {
        while (qtdv2 > 0) {
            vAux[i] = vet[v2];
            nTrocas++;
            i++;
            v2++;
            qtdv2--;
        }
    }
    for (i = 0; i < fim - inicio + 1; i++) {
        vet[inicio + i] = vAux[i];
        nTrocas++;
    }
    return;
}

/** Ordena a região de vector[] compreendida entre bgn inclusive e end inclusive. **/
void mergeSort(int vector[], int bgn,int end) {
    if(bgn<end) {
        int middle = (bgn+end)/2;
        mergeSort(vector, bgn,middle);
        mergeSort(vector, middle+1,end);
        merge_inPlace(vector, bgn,middle, middle+1,end);
    }
}


/**
 ** Mescla as secções ordenadas [i,m] e [j,n] de vect[] numa só secção ordenada [i,n], sem uso de
 **qualquer espaço adicional.
 **/
void merge_inPlace(int vect[], int i,int m, int j,int n) {
 int temp; /* Variábil a se utilizar na transferência de valores entre os vectores. */
 int comp; /* Índice da secção do vector sendo comparada no algorithmo explicado abaixo. */

 while(i<=m) {              /* Porque, se o primeiro vector se acabar, o vector final estará já ordenado.*/
  if(vect[i]<=vect[j]) i++; /* Se o primeiro campo do primeiro vector é o menor, já está na posição correcta.*/

  /*
   * Agora a cousa fica interessante; se o elemento seguinte está no segundo vector, ele é trazido
   *para o início do primeiro vector, tornando-se o final da parte já ordenada. O elemento que era*
   *o primeiro desse vector é inserido no segundo, por meio de huma adaptação do
   *algorithmo do InsertionSort, que é especifica demais pera haver sua própria função.
   *
   * Façamo-lo!
   */
  else {
   temp = vect[i];       /* Backup do antigo elemento inicial do primeiro vector. */
   vect[i++] = vect[j];  /* Moção do menor dos elementos pera seu devido lugar. */

   /*
    * Agora algo que não sey se foy tentado antes; achey conceiptos similares, mas creio ter
    *inventado este méthodo de minha própria mente.
    *
    * O algorithmo usa a variável comp criada mais acima como índice, comparando o valor de temp
    *progressivamente com cada um dos elementos do segundo vector, a partir de j+1 rumo a n posicio-
    *nando-o em seu devido local.
    */

   comp = j+1;

   /*
    * Corre o vector, movendo elementos para a esquerda, até o local onde se deve inserir o
    *componente desejado.
    */
   while(comp<=n && temp>vect[comp]) {
    vect[comp-1] = vect[comp];
    comp++;
   }

   /* Insere o componente novo onde cabe. */
   vect[comp-1] = temp;
  }

 }
}

int main(int argc, char** argv) {
    clock_t start, end;
    int *vet, tam;
    char nome[20];
    if ((vet = (int*) calloc(1, sizeof (int))) == NULL)
        exit(1);
    printf("entre com o nome do arquivo de entrada\n");
    scanf("%s", nome);
    tam = OpenFileRead(nome, &vet);
    start = clock();
    mergeSort(vet, 0, tam - 1);
    end = clock();
    printf("entre com o nome do arquivo de saida\n");
    scanf("%s", nome);
    //Saida estatisticas 
    //tempo
    printf("tempo: %lf", (long double) (end - start));
    //Trocas
    OpenFileWrite(nome, vet, tam);
    return (EXIT_SUCCESS);
}

